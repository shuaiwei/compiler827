def __funcCalledARG1__(c):
return (c*c)
end

def __funcCalledARG2__(a , c):
b=0
if (-a != -20 + c): b = (a + 1) % 2
else end
if (-a == -20 % 3): b = a + 2 - 3 
else end
if __funcCalledARG1__(a): b = a - (2.5 + -3)
else end
if a < 50.9: b = (a + b - 2 ) 
else end
if a > 50: b = a / -4.2 
else end
if a >= 50: b = __funcCalledARG1__(a) % -5 - 2 
else end
if (__funcCalledARG1__(a) <= 50): b = a ** 6 
else end
return (b+c-2.2)
end

def __funcCalledARG13__(a, b ,c):
d = a + c - b ** 2;
d = 100 + 3.4 -3.7 ** 2 + a - b;
print (__funcCalledARG2__(1 , 2) + 3)
return (a+2) / (b - c) * a + b
end

def __myFunc__():
d = (20 + 30) / 10.0
e = (d + 4) ** __funcCalledARG1__(2)
if (d < -10): print e  
else: print __funcCalledARG2__(e, 1) 
end
return __funcCalledARG1__(e) 
if(d >= e + 2): print 2
else end
end