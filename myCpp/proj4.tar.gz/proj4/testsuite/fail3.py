def __funcCalledARG1__(a, b):
if (-a != -20 + c): b = (--a + 1) % 2
else end
end


