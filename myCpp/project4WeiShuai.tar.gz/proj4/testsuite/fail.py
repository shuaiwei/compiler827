def __funcCalledARG2__(a):
b = (a + 1 *) 
return b
end
