def __funcCalledARG1__(a, b):
	printf a;
end


